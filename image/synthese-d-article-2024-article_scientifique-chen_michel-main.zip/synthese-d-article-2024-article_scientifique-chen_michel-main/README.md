# Non-local means

[Rapport de l'article Non-local means par CHEN Michel E4FI](https://github.com/ESIEECourses/synthese-d-article-2024-article_scientifique-chen_michel/blob/main/Compte%20rendu%20NL%20Mean%20CHEN%20Michel.pdf)

## Guide d'utilisation 

Utilisation des scripts et exécutables pour Non-Local Means Denoising
L'algorithme Non-Local Means (NL-means) implémenté dans le projet IPOL offre un moyen efficace de débruiter des images en remplaçant la couleur d'un pixel par la moyenne des pixels similaires, indépendamment de leur distance.

Voici comment utiliser les scripts et exécutables fournis pour débruiter des images avec cet algorithme.

### 1. Pré-requis
Le code est écrit en ANSI C et C++, et nécessite :

Un compilateur ANSI C/C++.
La bibliothèque libpng pour gérer les images au format PNG.
OPENMP pour le parallélisme, ce qui nécessite une version récente de gcc (au moins 4.2 ou plus).
### 2. Compilation
Pour compiler le programme, utilisez simplement le Makefile fourni. Exécutez la commande suivante dans le terminal depuis le répertoire du projet :


```
make
```

Cela générera les exécutables.

En cas de librairie manquante, exécutez ces commandes :
```
sudo apt-get update
sudo apt-get install libpng-dev 
```

### 3. Usage
Cette fonction est l'exécutable principal qui applique l'algorithme NL-Means à une image donnée. Son utilisation est décrite dans le fichier nlmeans_ipol.cpp.
```
./nlmeans_ipol in.png sigma add_noise noisy.png denoised.png
```

Paramètres :
- in.png : L'image d'entrée sans bruit (image originale).
- sigma : L'écart-type du bruit (par exemple, 10 ou 20). Cela définit l'intensité du bruit ajouté ou estimé.
- add_noise : Peut être 1 ou 0. 1 pour ajouter du bruit à l'image initiale, et 0 pour ne pas ajouter de bruit.
- noisy.png : L'image bruitée utilisée par l'algorithme. Si add_noise est à 1, l'image bruitée sera générée automatiquement.
- denoised.png : L'image débruitée qui sera générée par l'algorithme NL-means.

#### Ajout de bruit et débruitage
Si vous voulez ajouter un bruit avec un écart-type de 10 à l'image lena.png et ensuite appliquer le débruitage NL-means, vous pouvez exécuter la commande suivante :

```
./nlmeans_ipol lena.png 10 1 lena_noisy.png lena_denoised.png
```
#### Calcul de l'erreur quadratique moyenne (MSE)
Cette fonction calcule l'erreur quadratique moyenne (Mean Squared Error) entre deux images. Elle est utilisée pour évaluer la qualité d'une image débruitée en la comparant à l'image originale non bruitée.
```
./img_mse_ipol image1  image2
```
Paramètres :
- image1  : Chemin de la première image (généralement l'image originale sans bruit).
- image2 : Chemin de la deuxième image (généralement l'image débruitée ou bruitée).

#### Calcul de la différence entre deux images
Cette fonction calcule la différence entre deux images et génère une image de différence. Cela permet de visualiser les changements entre deux images (par exemple, entre une image d'origine et une image débruitée).
```
./img_diff_ipol image1 image2 diff_output
```
Paramètres :
- image1 : Chemin de la première image (par exemple, l'image originale).
- image2 : Chemin de la deuxième image (par exemple, l'image débruitée).
- diff_output : Chemin de l'image de différence à générer.

### 5. Résultats attendus
noisy.png : L'image bruitée générée (si le bruit est ajouté) ou l'image bruitée d'entrée.
denoised.png : L'image finale débruitée par l'algorithme NL-means.

### 6. Licences et droits
Les fichiers nlmeans_ipol.cpp, libdenoising.cpp, et libdenoising.h peuvent être liés au brevet EP 1,749,278 par A. Buades, T. Coll, et J.M. Morel. Ils sont fournis uniquement à des fins scientifiques et éducatives.

[Lien vers l'article source](https://www.ipol.im/pub/art/2011/bcm_nlm/)
